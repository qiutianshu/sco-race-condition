#define FUSE_USE_VERSION	30
#include <fcntl.h>
#include <fuse.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdatomic.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>

#define EVIL_PATH   "evil"
extern int fuse_pipes[2];

int evil_read(const char *path, char *buf, size_t size, off_t offset,
              struct fuse_file_info *fi);

int evil_getattr(const char *path, struct stat *stbuf);

int evil_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
             off_t offset, struct fuse_file_info *fi);