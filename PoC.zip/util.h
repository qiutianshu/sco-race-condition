#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

extern char kern_log[4096];

int setup_modprobe_hax();

unsigned long leak_addr();